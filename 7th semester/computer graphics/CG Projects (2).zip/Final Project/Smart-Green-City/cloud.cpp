#include <GL/glu.h>
#include <iostream>
#include <math.h>
#include <windows.h>

#include "draw.h"

#define PI 3.141516

using namespace std;

void
drawCloud (GLfloat circlePointX, GLfloat circlePointY)

{
    GLfloat radius = 0.1f;
    int triangle = 40;
    GLfloat trianglePoint = 2.0f * PI;
    glBegin (GL_TRIANGLE_FAN);
    glColor3ub (255, 255, 255);
    glVertex2f (circlePointX, circlePointY);
    for (int i = 0; i <= triangle; i++)
        {
            glVertex2f (
                circlePointX + (radius * cos (i * trianglePoint / triangle)),
                circlePointY + (radius * sin (i * trianglePoint / triangle)));
        }
    glEnd ();

    circlePointX = circlePointX - 0.1;
    radius = 0.075f;
    triangle = 40;
    trianglePoint = 2.0f * PI;
    glBegin (GL_TRIANGLE_FAN);
    glColor3ub (255, 255, 255);
    glVertex2f (circlePointX, circlePointY);
    for (int i = 0; i <= triangle; i++)
        {
            glVertex2f (
                circlePointX + (radius * cos (i * trianglePoint / triangle)),
                circlePointY + (radius * sin (i * trianglePoint / triangle)));
        }
    glEnd ();

    circlePointX = circlePointX + 0.2;
    radius = 0.075f;
    triangle = 40;
    trianglePoint = 2.0f * PI;
    glBegin (GL_TRIANGLE_FAN);
    glColor3ub (255, 255, 255);
    glVertex2f (circlePointX, circlePointY);
    for (int i = 0; i <= triangle; i++)
        {
            glVertex2f (
                circlePointX + (radius * cos (i * trianglePoint / triangle)),
                circlePointY + (radius * sin (i * trianglePoint / triangle)));
        }
    glEnd ();

    circlePointX = circlePointX + 0.1;
    radius = 0.050f;
    triangle = 40;
    trianglePoint = 2.0f * PI;
    glBegin (GL_TRIANGLE_FAN);
    glColor3ub (255, 255, 255);
    glVertex2f (circlePointX, circlePointY);
    for (int i = 0; i <= triangle; i++)
        {
            glVertex2f (
                circlePointX + (radius * cos (i * trianglePoint / triangle)),
                circlePointY + (radius * sin (i * trianglePoint / triangle)));
        }
    glEnd ();
}
