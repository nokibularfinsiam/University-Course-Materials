#include "draw.h"
#include <GL/glut.h>
#include <iostream>
#include <math.h>

using namespace std;

#define PI 3.141516

void
drawCar ()
{
    glBegin(GL_POLYGON);
	glColor3ub(0, 0, 0);
	glVertex2f (-0.8f, -0.20625f);
	glVertex2f (-0.8f, 0.0f);
	glVertex2f (-0.675f, 0.0f);
	glVertex2f (-0.575f, -0.103125f);
	glVertex2f (-0.575f, -0.20625f);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(189, 195, 199);
	glVertex2f (-0.79f, -0.103125f);
	glVertex2f (-0.79f, -0.02f);
		glVertex2f (-0.7235f, -0.02f);
	glVertex2f (-0.7235f, -0.103125f);

	glEnd();
	glBegin(GL_POLYGON);
	glVertex2f (-0.7215f, -0.103125f);
	glVertex2f (-0.7215f, -0.02f);
	glVertex2f (-0.675f, -0.02f);
	glVertex2f (-0.595f, -0.103125f);
	glEnd();

	GLfloat circlePointX = -0.75f;
    GLfloat circlePointY = -0.20625f;
    GLfloat radius = 0.02f;
    int triangle = 40;
    GLfloat trianglePoint = 2.0f * PI;
    glBegin (GL_TRIANGLE_FAN);
    glColor3ub (0, 0, 0);
    glVertex2f (circlePointX, circlePointY);
    for (int i = 0; i <= triangle; i++)
        {
            glVertex2f (
                circlePointX + (radius * cos (i * trianglePoint / triangle)),
                circlePointY + (radius * sin (i * trianglePoint / triangle)));
        }
    glEnd ();

    circlePointX = -0.625f;
    circlePointY = -0.20625f;
    glBegin (GL_TRIANGLE_FAN);
    glColor3ub (0, 0, 0);
    glVertex2f (circlePointX, circlePointY);
    for (int i = 0; i <= triangle; i++)
        {
            glVertex2f (
                circlePointX + (radius * cos (i * trianglePoint / triangle)),
                circlePointY + (radius * sin (i * trianglePoint / triangle)));
        }
    glEnd ();

    circlePointX = -0.75f;
    circlePointY = -0.20625f;
    radius = 0.01f;
    glBegin (GL_TRIANGLE_FAN);
    glColor3ub (255, 255, 255);
    glVertex2f (circlePointX, circlePointY);
    for (int i = 0; i <= triangle; i++)
        {
            glVertex2f (
                circlePointX + (radius * cos (i * trianglePoint / triangle)),
                circlePointY + (radius * sin (i * trianglePoint / triangle)));
        }
    glEnd ();

circlePointX = -0.625f;
    circlePointY = -0.20625f;
    glBegin (GL_TRIANGLE_FAN);
    glColor3ub (255, 255, 255);
    glVertex2f (circlePointX, circlePointY);
    for (int i = 0; i <= triangle; i++)
        {
            glVertex2f (
                circlePointX + (radius * cos (i * trianglePoint / triangle)),
                circlePointY + (radius * sin (i * trianglePoint / triangle)));
        }
    glEnd ();


}
