#include "draw.h"
#include <GL/glut.h>
#include <iostream>
#include <math.h>

using namespace std;

#define PI 3.141516

void
drawBoat ()
{
    glBegin(GL_POLYGON);
	glColor3ub(225, 112, 85);
	glVertex2f (-0.8f, -0.8f);
	glVertex2f (-0.8f, -0.65f);
	glVertex2f (-0.5f, -0.65f);
	glVertex2f (-0.6f, -0.8f);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(178, 190, 195);
	glVertex2f (-0.765f, -0.6f);
	glVertex2f (-0.775f, -0.5);
	glVertex2f (-0.575f, -0.5);
	glVertex2f (-0.565f, -0.6);
	glEnd();

	glBegin(GL_POLYGON);
	glColor3ub(99, 110, 85);
	glVertex2f (-0.755f, -0.59f);
	glVertex2f (-0.765f, -0.51);
	glVertex2f (-0.585f, -0.51);
	glVertex2f (-0.575f, -0.59);
	glEnd();

	glLineWidth(5.0);
	glBegin(GL_LINES);
	glColor3ub(45, 52, 54);
	glVertex2f (-0.765f, -0.6f);
	glVertex2f (-0.765f, -0.65f);
	glEnd();

	glBegin(GL_LINES);
	glColor3ub(45, 52, 54);
	glVertex2f (-0.575f, -0.6);
	glVertex2f (-0.575f, -0.65);

	glEnd();




}
