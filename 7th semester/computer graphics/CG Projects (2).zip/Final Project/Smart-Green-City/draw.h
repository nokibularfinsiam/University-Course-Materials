#include <GL/glut.h>

void drawTree(int, int, int, float, float);
void drawCar();
void drawSmallBuilding(float);
void drawBigBuilding(float);
void drawCloud(GLfloat, GLfloat);
void drawHospital(float);
void drawSchool(float);
void drawBoat();
void drawMarket(float);
