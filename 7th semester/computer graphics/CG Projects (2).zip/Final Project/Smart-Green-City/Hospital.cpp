#include <iostream>
#include <windows.h>
#include <GL/glu.h>
#include "draw.h"

using namespace std;


void drawHospital(float buildingPositionX)
{

    glBegin(GL_QUADS);
    glColor3ub(255, 255, 255);
    glVertex2f(buildingPositionX, 0.535f);
    glVertex2f(buildingPositionX + 0.35, 0.535f);
    glVertex2f(buildingPositionX + 0.35, -0.115f);
    glVertex2f(buildingPositionX, -0.115f);
    glEnd();



    glColor3ub(243, 156, 18);
    glBegin(GL_QUADS);
    glVertex2f(buildingPositionX + 0.05, -0.015f);
    glVertex2f(buildingPositionX + 0.1, -0.015f);
    glVertex2f(buildingPositionX + 0.1, -0.065f);
    glVertex2f(buildingPositionX + 0.05, -0.065f);
    glEnd();

    glColor3ub(243, 156, 18);
    glBegin(GL_QUADS);
    glVertex2f(buildingPositionX + 0.15, -0.015f);
    glVertex2f(buildingPositionX + 0.20, -0.015f);
    glVertex2f(buildingPositionX + 0.20, -0.065f);
    glVertex2f(buildingPositionX + 0.15, -0.065f);
    glEnd();

        glColor3ub(243, 156, 18);
    glBegin(GL_QUADS);
    glVertex2f(buildingPositionX + 0.25, -0.015f);
    glVertex2f(buildingPositionX + 0.30, -0.015f);
    glVertex2f(buildingPositionX + 0.30, -0.065f);
    glVertex2f(buildingPositionX + 0.25, -0.065f);
    glEnd();

    glColor3ub(243, 156, 18);
    glBegin(GL_QUADS);
    glVertex2f(buildingPositionX + 0.05, 0.085f);
    glVertex2f(buildingPositionX + 0.1, 0.085f);
    glVertex2f(buildingPositionX + 0.1, 0.035f);
    glVertex2f(buildingPositionX + 0.05, 0.035f);
    glEnd();

    glColor3ub(243, 156, 18);
    glBegin(GL_QUADS);
    glVertex2f(buildingPositionX + 0.15, 0.085f);
    glVertex2f(buildingPositionX + 0.20, 0.085f);
    glVertex2f(buildingPositionX + 0.20, 0.035f);
    glVertex2f(buildingPositionX + 0.15, 0.035f);
    glEnd();

    glColor3ub(243, 156, 18);
    glBegin(GL_QUADS);
    glVertex2f(buildingPositionX + 0.25, 0.085f);
    glVertex2f(buildingPositionX + 0.30, 0.085f);
    glVertex2f(buildingPositionX + 0.30, 0.035f);
    glVertex2f(buildingPositionX + 0.25, 0.035f);
    glEnd();


    glColor3ub(243, 156, 18);
    glBegin(GL_QUADS);
    glVertex2f(buildingPositionX + 0.05, 0.185f);
    glVertex2f(buildingPositionX + 0.1, 0.185f);
    glVertex2f(buildingPositionX + 0.1, 0.135f);
    glVertex2f(buildingPositionX + 0.05, 0.135f);
    glEnd();

    glColor3ub(243, 156, 18);
    glBegin(GL_QUADS);
    glVertex2f(buildingPositionX + 0.15, 0.185f);
    glVertex2f(buildingPositionX + 0.20, 0.185f);
    glVertex2f(buildingPositionX + 0.20, 0.135f);
    glVertex2f(buildingPositionX + 0.15, 0.135f);
    glEnd();

    glColor3ub(243, 156, 18);
    glBegin(GL_QUADS);
    glVertex2f(buildingPositionX + 0.25, 0.185f);
    glVertex2f(buildingPositionX + 0.30, 0.185f);
    glVertex2f(buildingPositionX + 0.30, 0.135f);
    glVertex2f(buildingPositionX + 0.25, 0.135f);
    glEnd();

    glColor3ub(243, 156, 18);
    glBegin(GL_QUADS);
    glVertex2f(buildingPositionX + 0.05, 0.285f);
    glVertex2f(buildingPositionX + 0.1, 0.285f);
    glVertex2f(buildingPositionX + 0.1, 0.235f);
    glVertex2f(buildingPositionX + 0.05, 0.235f);
    glEnd();

    glColor3ub(243, 156, 18);
    glBegin(GL_QUADS);
    glVertex2f(buildingPositionX + 0.15, 0.285f);
    glVertex2f(buildingPositionX + 0.20, 0.285f);
    glVertex2f(buildingPositionX + 0.20, 0.235f);
    glVertex2f(buildingPositionX + 0.15, 0.235f);
    glEnd();

    glColor3ub(243, 156, 18);
    glBegin(GL_QUADS);
    glVertex2f(buildingPositionX + 0.25, 0.285f);
    glVertex2f(buildingPositionX + 0.30, 0.285f);
    glVertex2f(buildingPositionX + 0.30, 0.235f);
    glVertex2f(buildingPositionX + 0.25, 0.235f);
    glEnd();

    glColor3ub(243, 156, 18);
    glBegin(GL_QUADS);
    glVertex2f(buildingPositionX + 0.05, 0.385f);
    glVertex2f(buildingPositionX + 0.1, 0.385f);
    glVertex2f(buildingPositionX + 0.1, 0.335f);
    glVertex2f(buildingPositionX + 0.05, 0.335f);
    glEnd();

    glColor3ub(243, 156, 18);
    glBegin(GL_QUADS);
    glVertex2f(buildingPositionX + 0.15, 0.385f);
    glVertex2f(buildingPositionX + 0.20, 0.385f);
    glVertex2f(buildingPositionX + 0.20, 0.335f);
    glVertex2f(buildingPositionX + 0.15, 0.335f);
    glEnd();

    glColor3ub(243, 156, 18);
    glBegin(GL_QUADS);
    glVertex2f(buildingPositionX + 0.25, 0.385f);
    glVertex2f(buildingPositionX + 0.30, 0.385f);
    glVertex2f(buildingPositionX + 0.30, 0.335f);
    glVertex2f(buildingPositionX + 0.25, 0.335f);
    glEnd();



}
