#include<iostream>
#include <GL/glut.h>
#include "draw.h"
#include<math.h>
#include <Windows.h>
#include <MMSystem.h>


GLfloat position = 0.0f;
GLfloat speed = 0.0f;

GLfloat boatPosition = 0.0f;
GLfloat boatSpeed = 0.01f;

GLfloat cloudPosition = 0.0f;
GLfloat cloudSpeed = 0.03f;

GLfloat wavePosition = 0.0f;
GLfloat waveSpeed = 0.03f;

GLfloat rainPosition = 0.0f;
GLfloat rainSpeed = 0.05f;

bool drawRain = false;

int skyRed = 116;
int skyGreen = 185;
int skyBlue = 255;

int riverRed = 52;
int riverGreen = 152;
int riverBlue = 219;

void updateCloud(int);
void updateBoat(int);
void updateWave(int);
void updateRain(int);

void update (int value)
{
    position -= speed;

    glutPostRedisplay ();
    glutTimerFunc (0, updateBoat, 0);

}

void updateBoat (int value)
{
    if(boatPosition > 1.5)
        boatPosition = 1.0;
    boatPosition += boatSpeed;

    glutPostRedisplay ();
    glutTimerFunc (0, updateCloud, 0);
}

void updateCloud (int value)
{
    if(cloudPosition > 2.0)
        cloudPosition = -1.5;
    cloudPosition += cloudSpeed;

    glutPostRedisplay ();
    glutTimerFunc (0, updateWave, 0);
}

void updateWave (int value)
{
    if(wavePosition < 0.0)
        wavePosition = 0.5;
    wavePosition -= waveSpeed;

    glutPostRedisplay ();
    glutTimerFunc (0, updateRain, 0);
}

void updateRain (int value)
{
    if(rainPosition < -0.1)
        rainPosition = 0.1;
    rainPosition -= rainSpeed;

    glutPostRedisplay ();
    glutTimerFunc (100, update, 0);
}

void init ()
{
    glClearColor (0.0, 0.0, 0.0, 1.0);
}

void rain()
{
    for (float i = -1.0f; i < 1.0f; i += 0.1f)
    {
        glPushMatrix();
    glTranslatef(0.0, wavePosition, 0.0);

        glLineWidth(1.0);
	glBegin(GL_LINES);
	glColor3ub(255, 255, 255);
	glVertex2f (-0.9, i);
	glVertex2f (-0.95, i + 0.1);
	glEnd();
	glPopMatrix();
	i += 0.1;
    }
    for (float i = -1.0f; i < 1.0f; i += 0.1f)
    {
        glPushMatrix();
    glTranslatef(0.0, wavePosition, 0.0);

        glLineWidth(1.0);
	glBegin(GL_LINES);
	glColor3ub(255, 255, 255);
	glVertex2f (-0.8, i);
	glVertex2f (-0.85, i + 0.1);
	glEnd();
	glPopMatrix();
	i += 0.1;
    }
    for (float i = -1.0f; i < 1.0f; i += 0.1f)
    {
        glPushMatrix();
    glTranslatef(0.0, wavePosition, 0.0);

        glLineWidth(1.0);
	glBegin(GL_LINES);
	glColor3ub(255, 255, 255);
	glVertex2f (-0.7, i);
	glVertex2f (-0.75, i + 0.1);
	glEnd();
	glPopMatrix();
	i += 0.1;
    }
    for (float i = -1.0f; i < 1.0f; i += 0.1f)
    {
        glPushMatrix();
    glTranslatef(0.0, wavePosition, 0.0);

        glLineWidth(1.0);
	glBegin(GL_LINES);
	glColor3ub(255, 255, 255);
	glVertex2f (-0.6, i);
	glVertex2f (-0.65, i + 0.1);
	glEnd();
	glPopMatrix();
	i += 0.1;
    }
    for (float i = -1.0f; i < 1.0f; i += 0.1f)
    {
        glPushMatrix();
    glTranslatef(0.0, wavePosition, 0.0);

        glLineWidth(1.0);
	glBegin(GL_LINES);
	glColor3ub(255, 255, 255);
	glVertex2f (-0.5, i);
	glVertex2f (-0.55, i + 0.1);
	glEnd();
	glPopMatrix();
	i += 0.1;
    }
    for (float i = -1.0f; i < 1.0f; i += 0.1f)
    {
        glPushMatrix();
    glTranslatef(0.0, wavePosition, 0.0);

        glLineWidth(1.0);
	glBegin(GL_LINES);
	glColor3ub(255, 255, 255);
	glVertex2f (-0.4, i);
	glVertex2f (-0.45, i + 0.1);
	glEnd();
	glPopMatrix();
	i += 0.1;
    }
    for (float i = -1.0f; i < 1.0f; i += 0.1f)
    {
        glPushMatrix();
    glTranslatef(0.0, wavePosition, 0.0);

        glLineWidth(1.0);
	glBegin(GL_LINES);
	glColor3ub(255, 255, 255);
	glVertex2f (-0.3, i);
	glVertex2f (-0.35, i + 0.1);
	glEnd();
	glPopMatrix();
	i += 0.1;
    }
    for (float i = -1.0f; i < 1.0f; i += 0.1f)
    {
        glPushMatrix();
    glTranslatef(0.0, wavePosition, 0.0);

        glLineWidth(1.0);
	glBegin(GL_LINES);
	glColor3ub(255, 255, 255);
	glVertex2f (-0.2, i);
	glVertex2f (-0.25, i + 0.1);
	glEnd();
	glPopMatrix();
	i += 0.1;
    }
    for (float i = -1.0f; i < 1.0f; i += 0.1f)
    {
        glPushMatrix();
    glTranslatef(0.0, wavePosition, 0.0);

        glLineWidth(1.0);
	glBegin(GL_LINES);
	glColor3ub(255, 255, 255);
	glVertex2f (-0.1, i);
	glVertex2f (-0.15, i + 0.1);
	glEnd();
	glPopMatrix();
	i += 0.1;
    }
    for (float i = -1.0f; i < 1.0f; i += 0.1f)
    {
        glPushMatrix();
    glTranslatef(0.0, wavePosition, 0.0);

        glLineWidth(1.0);
	glBegin(GL_LINES);
	glColor3ub(255, 255, 255);
	glVertex2f (0.0, i);
	glVertex2f (-0.05, i + 0.1);
	glEnd();
	glPopMatrix();
	i += 0.1;
    }
    for (float i = -1.0f; i < 1.0f; i += 0.1f)
    {
        glPushMatrix();
    glTranslatef(0.0, wavePosition, 0.0);

        glLineWidth(1.0);
	glBegin(GL_LINES);
	glColor3ub(255, 255, 255);
	glVertex2f (0.15, i);
	glVertex2f (0.1, i + 0.1);
	glEnd();
	glPopMatrix();
	i += 0.1;
    }
    for (float i = -1.0f; i < 1.0f; i += 0.1f)
    {
        glPushMatrix();
    glTranslatef(0.0, wavePosition, 0.0);

        glLineWidth(1.0);
	glBegin(GL_LINES);
	glColor3ub(255, 255, 255);
	glVertex2f (0.25, i);
	glVertex2f (0.2, i + 0.1);
	glEnd();
	glPopMatrix();
	i += 0.1;
    }
    for (float i = -1.0f; i < 1.0f; i += 0.1f)
    {
        glPushMatrix();
    glTranslatef(0.0, wavePosition, 0.0);

        glLineWidth(1.0);
	glBegin(GL_LINES);
	glColor3ub(255, 255, 255);
	glVertex2f (0.35, i);
	glVertex2f (0.3, i + 0.1);
	glEnd();
	glPopMatrix();
	i += 0.1;
    }
    for (float i = -1.0f; i < 1.0f; i += 0.1f)
    {
        glPushMatrix();
    glTranslatef(0.0, wavePosition, 0.0);

        glLineWidth(1.0);
	glBegin(GL_LINES);
	glColor3ub(255, 255, 255);
	glVertex2f (0.45, i);
	glVertex2f (0.4, i + 0.1);
	glEnd();
	glPopMatrix();
	i += 0.1;
    }
    for (float i = -1.0f; i < 1.0f; i += 0.1f)
    {
        glPushMatrix();
    glTranslatef(0.0, wavePosition, 0.0);

        glLineWidth(1.0);
	glBegin(GL_LINES);
	glColor3ub(255, 255, 255);
	glVertex2f (0.55, i);
	glVertex2f (0.5, i + 0.1);
	glEnd();
	glPopMatrix();
	i += 0.1;
    }
    for (float i = -1.0f; i < 1.0f; i += 0.1f)
    {
        glPushMatrix();
    glTranslatef(0.0, wavePosition, 0.0);

        glLineWidth(1.0);
	glBegin(GL_LINES);
	glColor3ub(255, 255, 255);
	glVertex2f (0.65, i);
	glVertex2f (0.6, i + 0.1);
	glEnd();
	glPopMatrix();
	i += 0.1;
    }
    for (float i = -1.0f; i < 1.0f; i += 0.1f)
    {
        glPushMatrix();
    glTranslatef(0.0, wavePosition, 0.0);

        glLineWidth(1.0);
	glBegin(GL_LINES);
	glColor3ub(255, 255, 255);
	glVertex2f (0.75, i);
	glVertex2f (0.7, i + 0.1);
	glEnd();
	glPopMatrix();
	i += 0.1;
    }
    for (float i = -1.0f; i < 1.0f; i += 0.1f)
    {
        glPushMatrix();
    glTranslatef(0.0, wavePosition, 0.0);

        glLineWidth(1.0);
	glBegin(GL_LINES);
	glColor3ub(255, 255, 255);
	glVertex2f (0.85, i);
	glVertex2f (0.8, i + 0.1);
	glEnd();
	glPopMatrix();
	i += 0.1;
    }
    for (float i = -1.0f; i < 1.0f; i += 0.1f)
    {
        glPushMatrix();
    glTranslatef(0.0, wavePosition, 0.0);

        glLineWidth(1.0);
	glBegin(GL_LINES);
	glColor3ub(255, 255, 255);
	glVertex2f (0.95, i);
	glVertex2f (0.9, i + 0.1);
	glEnd();
	glPopMatrix();
	i += 0.1;
    }
}

void drawSky ()
{
    // Sky
    glColor3ub (skyRed, skyGreen, skyBlue);
    glBegin (GL_QUADS);
    glVertex2f (-1.0f, 1.0f);
    glVertex2f (1.0f, 1.0f);
    glVertex2f (1.0f, -0.33f);
    glVertex2f (-1.0f, -0.33f);
    glEnd ();
}

void drawRiver ()
{
    // River
    glColor3ub (riverRed, riverGreen, riverBlue);
    glBegin (GL_QUADS);
    glVertex2f (-1.0f, -0.33f);
    glVertex2f (1.0f, -0.33f);
    glVertex2f (1.0f, -1.0f);
    glVertex2f (-1.0f, -1.0f);
    glEnd ();
}

void star()
{
    glClear (GL_COLOR_BUFFER_BIT);
    glColor3ub (128, 128, 128);
    glPointSize(15.0);
    glBegin(GL_POINTS);
    glVertex2i(500, 500);
    glEnd();
    glFlush ();

}


void drawCircle(float cx, float cy, float r, int num_segments)
{
    float theta = 3.1415926 * 2 / float(num_segments);
    float tangetial_factor = tanf(theta);//calculate the tangential factor

    float radial_factor = cosf(theta);//calculate the radial factor

    float x = r;//we start at angle = 0

    float y = 0;
    glLineWidth(2);
    glBegin(GL_LINE_LOOP);
    for (int ii = 0; ii < num_segments; ii++)
    {
        glVertex2f(x + cx, y + cy);//output vertex

        //calculate the tangential vector
        //remember, the radial vector is (x, y)
        //to get the tangential vector we flip those coordinates and negate one of them

        float tx = -y;
        float ty = x;

        //add the tangential vector

        x += tx * tangetial_factor;
        y += ty * tangetial_factor;

        //correct using the radial factor

        x *= radial_factor;
        y *= radial_factor;
    }
    glEnd();
}


void Circle(GLfloat x, GLfloat y,GLfloat z, GLfloat radius,int r,int g,int b)
{
    int i;
    int triangleAmount = 200; //# of triangles used to draw circle

    //GLfloat radius = 0.8f; //radius
    GLfloat twicePi = 2.0f * 3.1416;
    int counter=0;
    glColor3ub(r,g,b);
    glBegin(GL_TRIANGLE_FAN);
    glVertex3f(x, y,z); // center of circle
    for(i = 0; i <= triangleAmount; i++)
    {
        counter+=1;
        glVertex3f(
            x + (radius * cos(i *  twicePi / triangleAmount)),
            y + (radius * sin(i * twicePi / triangleAmount)),z
        );
    }
    glEnd();

}

void display ()
{

    glClear (GL_COLOR_BUFFER_BIT);

    drawRiver ();

    drawSky ();
    drawCircle(1800, 980, 50, 360);


    // Hills
    glBegin(GL_POLYGON);
	glColor3ub(39, 174, 96);
	glVertex2f(0.0f, -0.115f);
	glVertex2f(0.1f, 0.1f);
	glVertex2f(0.2f, 0.2f);
	glVertex2f(0.3f, 0.3f);
	glVertex2f(0.4f, 0.4f);
	glVertex2f(0.5f, 0.5f);
	glVertex2f(0.6f, 0.4f);
	glVertex2f(0.7f, 0.3f);
	glVertex2f(0.8f, 0.2f);
	glVertex2f(1.0f, -0.115f);
	glEnd();

	// Hills
    glBegin(GL_POLYGON);
	glColor3ub(39, 174, 96);
	glVertex2f(-0.0f, -0.115f);
	glVertex2f(-0.1f, 0.1f);
	glVertex2f(-0.2f, 0.2f);
	glVertex2f(-0.3f, 0.3f);
	glVertex2f(-0.4f, 0.4f);
	glVertex2f(-0.5f, 0.5f);
	glVertex2f(-0.6f, 0.4f);
	glVertex2f(-0.7f, 0.3f);
	glVertex2f(-0.8f, 0.2f);
	glVertex2f(-1.0f, -0.115f);
	glEnd();

    // Road
    glColor3ub (127, 140, 141);
    glBegin (GL_QUADS);
    glVertex2f (-1.0f, -0.165f);
    glVertex2f (1.0f, -0.165f);
    glVertex2f (1.0f, -0.2475f);
    glVertex2f (-1.0f, -0.2475f);
    glEnd ();

    glColor3ub (149, 165, 166);
    glBegin (GL_QUADS);
    glVertex2f (-1.0f, -0.2475f);
    glVertex2f (1.0f, -0.2475f);
    glVertex2f (1.0f, -0.33f);
    glVertex2f (-1.0f, -0.33f);
    glEnd ();

    glColor3ub (99, 110, 114);
    glBegin (GL_QUADS);
    glVertex2f (1.0f, -0.33f);
    glVertex2f (-1.0f, -0.33f);
        glVertex2f (-1.0f, -0.45375f);
    glVertex2f (1.0f, -0.45375f);
    glEnd ();

    glLineWidth(10.0);
	glBegin(GL_LINES);
	glColor3ub(255, 255, 255);
    glVertex2f (1.0f, -0.33f);
    glVertex2f (-1.0f, -0.33f);
	glEnd();

	glLineWidth(10.0);
	glBegin(GL_LINES);
	glColor3ub(255, 255, 255);
    glVertex2f (-1.0f, -0.33f);
        glVertex2f (-1.0f, -0.45375f);
	glEnd();

	glLineWidth(10.0);
	glBegin(GL_LINES);
	glColor3ub(255, 255, 255);
        glVertex2f (-1.0f, -0.45375f);
    glVertex2f (1.0f, -0.45375f);
	glEnd();

	glLineWidth(10.0);
	glBegin(GL_LINES);
	glColor3ub(255, 255, 255);
    glVertex2f (1.0f, -0.33f);
    glVertex2f (1.0f, -0.45375f);
	glEnd();

	// train line
    for (float i = -1.0f; i < 1.0f; i += 0.1f)
    {

        glLineWidth(10.0);
	glBegin(GL_LINES);
	glColor3ub(255, 255, 255);
	glVertex2f (i, -0.33f);
	glVertex2f (i + 0.05, -0.45375f);
	glEnd();
    }

    // waves


       for (float i = -1.0f; i < 1.0f; i += 0.1f)
    {
        glPushMatrix();
    glTranslatef(-wavePosition, 0.0, 0.0);

        glLineWidth(2.5);
	glBegin(GL_LINES);
	glColor3ub(255, 255, 255);
	glVertex2f (i, -0.53f);
	glVertex2f (i + 0.1, -0.53f);
	glEnd();

	i += 0.1;
	glPopMatrix();
    }

    for (float i = -0.9f; i < 1.0f; i += 0.1f)
    {
        glPushMatrix();
    glTranslatef(-wavePosition, 0.0, 0.0);

        glLineWidth(2.5);
	glBegin(GL_LINES);
	glColor3ub(255, 255, 255);
	glVertex2f (i, -0.63f);
	glVertex2f (i + 0.1, -0.63f);
	glEnd();

	i += 0.2;
	glPopMatrix();
    }

    for (float i = -1.0f; i < 1.0f; i += 0.1f)
    {
        glPushMatrix();
    glTranslatef(-wavePosition, 0.0, 0.0);

        glLineWidth(2.5);
	glBegin(GL_LINES);
	glColor3ub(255, 255, 255);
	glVertex2f (i, -0.73f);
	glVertex2f (i + 0.1, -0.73f);
	glEnd();

	i += 0.1;
	glPopMatrix();
    }

    for (float i = -0.9f; i < 1.0f; i += 0.1f)
    {
        glPushMatrix();
    glTranslatef(-wavePosition, 0.0, 0.0);

        glLineWidth(2.5);
	glBegin(GL_LINES);
	glColor3ub(255, 255, 255);
	glVertex2f (i, -0.83f);
	glVertex2f (i + 0.1, -0.83f);
	glEnd();

	i += 0.2;
	glPopMatrix();
    }

    for (float i = -1.0f; i < 1.0f; i += 0.1f)
    {
        glPushMatrix();
    glTranslatef(-wavePosition, 0.0, 0.0);

        glLineWidth(2.5);
	glBegin(GL_LINES);
	glColor3ub(255, 255, 255);
	glVertex2f (i, -0.93f);
	glVertex2f (i + 0.1, -0.93f);
	glEnd();

	i += 0.1;
	glPopMatrix();
    }



    // Cloud
    glPushMatrix();
    glTranslatef(cloudPosition, 0.0, 0.0);
    drawCloud (-0.80f, 0.80f);
    glPopMatrix();

        glPushMatrix();
    glTranslatef(-cloudPosition, 0.0, 0.0);
    drawCloud (-0.60f, 0.60f);
    glPopMatrix();



    // Grass
    glColor3ub (46, 204, 113);
    glBegin (GL_QUADS);
    glVertex2f (-1.0f, -0.115f);
    glVertex2f (1.0f, -0.115f);
    glVertex2f (1.0f, -0.165f);
    glVertex2f (-1.0f, -0.165f);
    glEnd ();

    // Building
    for (int i = 0; i < 100; i++)
    {
            glPushMatrix();
    glTranslatef(position, 0.0, 0.0);
        drawSmallBuilding((float)i + 0.3);
        drawBigBuilding((float)i + 0.7);
            glPopMatrix();
    }

    //Hospital

    for (int i = 0; i < 100; i += 5)
    {
glPushMatrix();

    glTranslatef(position, 0.0, 0.0);
    drawHospital(i + 2.5);
            glPopMatrix();

    }

        // School
for (int i = 0; i < 100; i += 6)
    {
glPushMatrix();
    glTranslatef(position, 0.0, 0.0);
    drawSchool(i + 5);
            glPopMatrix();

    }

    // Market
for (int i = 0; i < 100; i += 7)
    {
glPushMatrix();
    glTranslatef(position, 0.0, 0.0);
    drawMarket(i + 7.5);
            glPopMatrix();

    }

    // Tree

    for (int i = 0; i < 100; i++)
    {
glPushMatrix();
    glTranslatef(position, 0.0, 0.0);

        drawTree(46, 204, 113, i, 0.1);
            glPopMatrix();

    }

    for (int i = 0; i < 100; i++)
    {
glPushMatrix();
    glTranslatef(position, 0.0, 0.0);

        drawTree(46, 204, 113, i + 0.2, 0.1);
            glPopMatrix();

    }

    for (int i = 0; i < 100; i++)
    {
glPushMatrix();
    glTranslatef(position, 0.0, 0.0);

        drawTree(46, 204, 113, i + 0.6, 0.1);
            glPopMatrix();

    }

    for (int i = 0; i < 100; i++)
    {
glPushMatrix();
    glTranslatef(position, 0.0, 0.0);

        drawTree(46, 204, 113, i + 0.8, 0.1);
            glPopMatrix();

    }

    for (int i = 0; i < 100; i++)
    {
glPushMatrix();
    glTranslatef(position, 0.0, 0.0);

        drawTree(46, 204, 113, i + 1, 0.1);
            glPopMatrix();

    }



    // Car
    drawCar ();

        // Boat
glPushMatrix();
    glTranslatef(boatPosition, 0.0, 0.0);
    drawBoat();
    glPopMatrix();

    // Train

    glPushMatrix();
    glTranslatef(-cloudPosition, 0.0, 0.0);

    glColor3ub (52, 31, 151);
    glBegin (GL_POLYGON);
    glVertex2f (-0.9f, -0.25f);
    glVertex2f (-0.7f, -0.25f);
    glVertex2f (-0.7f, -0.45375f);
    glVertex2f (-1.0f, -0.45375f);
    glEnd ();

    glBegin (GL_QUADS);
    glVertex2f (-0.69f, -0.25f);
    glVertex2f (-0.49f, -0.25f);
    glVertex2f (-0.49f, -0.45375f);
    glVertex2f (-0.69f, -0.45375f);
    glEnd ();

    glBegin (GL_QUADS);
    glVertex2f (-0.48f, -0.25f);
    glVertex2f (-0.28f, -0.25f);
    glVertex2f (-0.28f, -0.45375f);
    glVertex2f (-0.48f, -0.45375f);
    glEnd ();

    glBegin (GL_QUADS);
    glVertex2f (-0.27f, -0.25f);
    glVertex2f (-0.07f, -0.25f);
    glVertex2f (-0.07f, -0.45375f);
    glVertex2f (-0.27f, -0.45375f);
    glEnd ();

    // Train window

    glColor3ub (178, 190, 195);
    glBegin (GL_POLYGON);
    glVertex2f (-0.89f, -0.25f);
    glVertex2f (-0.71f, -0.25f);
    glVertex2f (-0.71f, -0.35f);
    glVertex2f (-0.930f, -0.35f);
    glEnd ();

    glColor3ub (178, 190, 195);
    glBegin (GL_QUADS);
    glVertex2f (-0.68f, -0.25f);
    glVertex2f (-0.50f, -0.25f);
    glVertex2f (-0.50f, -0.35f);
    glVertex2f (-0.68f, -0.35f);
    glEnd ();

    glColor3ub (178, 190, 195);
    glBegin (GL_QUADS);
    glVertex2f (-0.47f, -0.25f);
    glVertex2f (-0.29f, -0.25f);
    glVertex2f (-0.29f, -0.35f);
    glVertex2f (-0.47f, -0.35f);
    glEnd ();

    glColor3ub (178, 190, 195);
    glBegin (GL_QUADS);
    glVertex2f (-0.26f, -0.25f);
    glVertex2f (-0.08f, -0.25f);
    glVertex2f (-0.08f, -0.35f);
    glVertex2f (-0.26f, -0.35f);
    glEnd ();
    glPopMatrix();

    if (drawRain)
        rain();


    glFlush ();
}

void handleMouse (int button, int state, int x, int y)
{
    if (button == GLUT_LEFT_BUTTON)
        {
            speed += 0.01f;
        }
    if (button == GLUT_RIGHT_BUTTON)
        {
            speed -= 0.01f;
        }
    glutPostRedisplay ();
}

void handleKeypress (unsigned char key, int x, int y)
{
    switch (key)
        {
        case 's':
            {
                speed = 0.0f;
            }

            break;
        case 'f':
            {
                speed = 0.1f;
            }
            break;
        case 'n':
            {
                skyRed = 25;
                skyGreen = 25;
                skyBlue = 102;
                riverRed = 52;
                riverGreen = 73;
                riverBlue = 94;

                star();

            }
            break;

            case 'h':
            {

                skyRed = 25;
                skyGreen = 25;
                skyBlue = 102;
                riverRed = 52;
                riverGreen = 73;
                riverBlue = 94;
                drawRain = true;

            }
            break;

            case 'a':
            {

                skyRed = 178;
                skyGreen = 242;
                skyBlue = 172;
                riverRed = 52;
                riverGreen = 73;
                riverBlue = 94;

            }
            break;

        case 'd':
            {
                skyRed = 135;
                skyGreen = 206;
                skyBlue = 235;
                riverRed = 52;
                riverGreen = 152;
                riverBlue = 219;
                Circle(750.0f,700.0f,0.0f,50.0f,255,255,0);
            }
            break;

            case 'm':
            {
                skyRed = 250;
                skyGreen = 214;
                skyBlue = 165;
                riverRed = 52;
                riverGreen = 145;
                riverBlue = 175;
            }
            break;

        case 'r':
            {
                drawRain = true;
            }
            break;
        case 't':
            {
                drawRain = false;
            }
            break;
            glutPostRedisplay ();
        }
}

int main(int argc, char **argv)
{
    glutInit (&argc, argv);
    glutInitWindowSize (1920, 1080);
    glutCreateWindow ("Smart Green City");
    init ();
    glutDisplayFunc (display);
    glutTimerFunc (100, update, 0);
    glutKeyboardFunc (handleKeypress);
    glutMouseFunc (handleMouse);
    sndPlaySound("EHawa.wav", SND_ASYNC);
  //PlaySound(TEXT("EHawa.wav"), NULL, SND_SYNC);

    glutMainLoop ();

    return 0;
}
