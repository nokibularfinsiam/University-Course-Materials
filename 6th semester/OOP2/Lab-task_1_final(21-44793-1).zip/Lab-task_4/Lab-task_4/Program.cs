﻿using System;
namespace Lab_task_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Book b1 = new Book("Learn C#","Siam"," zdjfnrj", "Academic");
            string book = b1.ShowBookInfo();
            Console.WriteLine(book);
            Console.WriteLine();

            Library lib1 = new Library("AIUB BOOK STORE", "Kuratoli");
            lib1.ShowLibInfo();
            Console.WriteLine();


        }
    }
}