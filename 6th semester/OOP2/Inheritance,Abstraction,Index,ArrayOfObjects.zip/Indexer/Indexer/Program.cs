﻿using System;
namespace Indexer
{
    class OOP2G
    {
        private string[] name = new string[3];

        //indexer
        public string this[int index] //properites
        {
            set { name[index] = value; }
            get { return name[index]; }
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            OOP2G obj1 = new OOP2G();
            obj1[0] = "Arman";
            Console.WriteLine(obj1[0]);
            Console.WriteLine();
            obj1[1] = "Shefat";
            obj1[2] = "Rifat";

            for( int i = 0; i < 3; i++)
                Console.WriteLine(obj1[i]);




            Console.ReadKey();
        }
    }
}