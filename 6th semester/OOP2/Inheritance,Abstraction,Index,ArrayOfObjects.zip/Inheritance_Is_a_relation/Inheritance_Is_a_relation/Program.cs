﻿using System;
namespace Inheritance_Is_a_relation
{
    class A
    {
        private int num1; //private member
        public A() //default cons
        {
            this.num1 = 0;
            Console.WriteLine("A");
        }
        public int Num1 //properties
        {
            set { this.num1 = value; }
            get { return this.num1; }
        }
        virtual public void Method()
        {
            Console.WriteLine("Method A");
        }
    }
    class B:A
    {
        private int num2;
        public B()
        {
            this.num2 = 0;
            Console.WriteLine("B");
        }
        public B(int x, int y)
        {
            base.Num1 = x;
            this.num2 = y;
            Console.WriteLine("Para cons called!");
        }
        public int Num2
        {
            set { this.num2 = value; }
            get { return this.num2; }
        }
        override public void Method()
        {
            Console.WriteLine("Method B");
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            /**
            A obj1 = new A();
            obj1.Num1 = 1;
            Console.WriteLine(obj1.Num1);
            **/
            B obj1 = new B();
            obj1.Num1 = 1;
            obj1.Num2 = 2;
            Console.WriteLine(obj1.Num1 + " " + obj1.Num2);
            obj1.Method();
            Console.WriteLine();

            A obj2 = new B();
            obj2.Method();
            Console.WriteLine();

            B obj3 = new B(3,4);
            Console.WriteLine();

            A obj4 = new B();
            obj4.Num1 = 5;
            ((B)obj4).Num2 = 6;
            Console.WriteLine(obj4.Num1);
            Console.WriteLine(((B)obj4).Num2);





            Console.ReadKey();
            //
        }
    }
}