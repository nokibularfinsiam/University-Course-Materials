using System;
namespace Lab_task_3._2
{
    class Saloon : Vehicle
    {
        public Saloon()
        {
            this.VehicleName = " Sedon";
            this.VehicleId = " 33-4444";
        }
        public override void status()
        {
            Console.WriteLine("Saloon Name:" + this.VehicleName);
            Console.WriteLine("Saloon id:" + this.VehicleId);
        }
    }
}