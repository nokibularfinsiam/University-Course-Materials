using System;
namespace Lab_task_3._2
{
    class Truck : Vehicle
    {
        public Truck()
        {
            this.VehicleName = " El Grande";
            this.VehicleId = " 33-3r3";
        }
        public override void status()
        {
            Console.WriteLine("Truck Name:" + this.VehicleName);
            Console.WriteLine("Truck id:" + this.VehicleId);
        }
    }
}