using System;
namespace Lab_task_3._2
{
    class Motorbike: Vehicle
    {
        public Motorbike()
        {
            this.VehicleName = " Royal Enfield";
            this.VehicleId = " 33ff";
        }

        public override void status()
        {
            Console.WriteLine("Motorbike Name:" + this.VehicleName);
            Console.WriteLine("Motorbike id:" + this.VehicleId);
        }
    }
}