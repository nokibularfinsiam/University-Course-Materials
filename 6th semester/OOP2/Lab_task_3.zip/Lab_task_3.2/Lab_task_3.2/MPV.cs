using System;
namespace Lab_task_3._2
{
    class MPV : Vehicle
    {
        public MPV()
        {
            this.VehicleName = " Renault Triber";
            this.VehicleId = " 33-565655";
        }
        public override void status()
        {
            Console.WriteLine("MPV Name:" + this.VehicleName);
            Console.WriteLine("MPV id:" + this.VehicleId);
        }
    }
}