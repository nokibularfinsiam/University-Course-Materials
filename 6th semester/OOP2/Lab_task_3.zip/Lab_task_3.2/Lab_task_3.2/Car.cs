using System;
namespace Lab_task_3._2
{
    class Car : Vehicle
    {
        public Car()
        {
            this.VehicleName = " BMW";
            this.VehicleId = " 33-221";
        }
        public override void status()
        {
            Console.WriteLine("Car Name:" + this.VehicleName);
            Console.WriteLine("Car id:" + this.VehicleId);
        }
    }
}