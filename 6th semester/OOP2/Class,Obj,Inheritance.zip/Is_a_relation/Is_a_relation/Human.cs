﻿namespace Is_a_relation
{
    internal class Human
    {
        public string name1 = "I am from Human";
        virtual public void Method()
        {
            Console.WriteLine("Method from Human class");
        }
    }
}