﻿namespace Is_a_relation
{
    internal class CSE: Student
    {
        public string name3 = "I am from CSE";
        override public void Method()
        {
            Console.WriteLine("Method from CSE class");
        }
    }
}