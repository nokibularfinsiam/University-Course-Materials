﻿using System;
namespace Is_a_relation
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Human obj1 = new Human();
            Console.WriteLine(obj1.name1);
            obj1.Method();
            Console.WriteLine();
            //After inheritance
            Student obj2 = new Student();
            Console.WriteLine(obj2.name1);
            Console.WriteLine(obj2.name2);
            obj2.Method();
            Console.WriteLine();

            Human obj3 = new Student(); //Upcasting
            Console.WriteLine(obj3.name1);
            obj3.Method();
            ((Student)obj3).Method2();
            ((Student)obj3).callHuman();
            Console.WriteLine();

            Student obj4 = new CSE();
            Console.WriteLine(obj4.name1);
            Console.WriteLine(obj4.name2);
            obj4.Method();
            ((CSE)obj4).Method();
            Console.WriteLine();

            Console.ReadKey();
        }
    }
}