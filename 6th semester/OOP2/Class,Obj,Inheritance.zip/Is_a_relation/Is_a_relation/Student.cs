﻿namespace Is_a_relation
{
    internal class Student:Human
    {
        public string name2 = "I am from Student";
        override public void Method()
        {
            Console.WriteLine("Method from Student class");
        }
        public void Method2()
        {
            Console.WriteLine("Method2 from Student class");
        }
        public void callHuman()
        {
            base.Method();
        }
    }
}