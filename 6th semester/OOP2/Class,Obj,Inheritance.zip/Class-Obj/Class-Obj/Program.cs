﻿using System;
namespace Class_Obj
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Object obj1 = new Object();
            obj1.num1 = 2;
            obj1.num2 = 3;
            Console.WriteLine(obj1.num1 + " " + obj1.num2);
            Console.WriteLine();

            Object obj2 = new Object();
            obj2.num1 = 1;
            obj2.num2 = 2;
            obj2.Num3 = 3;
            obj2.Num4 = 4;
            Console.WriteLine(obj2.num1 + obj2.num2 + obj2.Num3 + obj2.Num4);
            Console.WriteLine();

            Object obj3 = new Object(5, 6);
            Console.WriteLine(obj3.num1);
            Console.WriteLine(obj3.num2);
            Console.WriteLine(obj3.Num3);
            Console.WriteLine(obj3.Num4);
            obj3.Show();
            Console.WriteLine();

            Object obj4 = new Object();
            Console.WriteLine(Object.count);
            Console.ReadKey();

        }
    }
}